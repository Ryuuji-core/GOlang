// Golang-sample1
package main

import (
	"fmt"
)

func main() {
fmt.Println("!Golang! !Golang!")
}
